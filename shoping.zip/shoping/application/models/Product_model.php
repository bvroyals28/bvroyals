<?php
class Product_model extends CI_Model{

  public function __construct($value='')
  {
      parent::__construct();
      $this->load->database();
      $CI = &get_instance();
    
  }

	public function getAllProduct($data=array())
	{
		$this->db->select("product_id,product_name,product_price,product_image");
		$this->db->from('product');
		$query = $this->db->get();
		$result = array();
		if($query->num_rows() > 0 )
		{
			$result = $query;
		}
		
		return $result;
	}
	
}