<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

	class Auth_verify
	{

		public $username;
		public $password;
        public $session_data = array();

		// Login user
		public function login_user()
		{				
			$CI =& get_instance();
			$CI->db->select("CONCAT(tu_first_name,' ',tu_last_name) as user_name,tu_password AS password,tu_status AS status,tu_gender AS gender,tu_role AS role,tu_ID AS user_id,tu_email AS email,tu_mobile AS mobile,tu_address AS user_address");
			$CI->db->from('tbl_users');
			$CI->db->where('tu_username',$this->username);
			$CI->db->where('tu_status' , 'ACTIVE');
			$data = $CI->db->get()->row_array();
			$db_hash_pwd = $data['password'];

			if (password_verify($this->password , $db_hash_pwd)) 
			{

				  $session_data = array(
						'role'       => $data['role'],
						'user_name' => $data['user_name'],
						'user_id'      => $data['user_id'],
						'user_status'  => $data['status'],
						'user_mail'  => $data['email'],
						'user_mobile'  => $data['mobile'],
						'user_address'  => $data['user_address'],
						'tupp_source'  => $data['tupp_source'],
						'tupp_filename'  => $data['tupp_filename'],
						'userprivileges'  => $permistiondata,
				
				  );

					$CI->session->set_userdata($session_data);
					return true;
			} 
			else 
			{
				return false;
				exit;
			}
		}  

		
		public function logout_user()
		{
			$CI =& get_instance();
			$CI->session->unset_userdata('role');
			$CI->session->unset_userdata('user_name');
			$CI->session->unset_userdata('user_id');
			$CI->session->unset_userdata('user_status');
			$CI->session->unset_userdata('user_mail');
			$CI->session->unset_userdata('user_mobile');
			$CI->session->unset_userdata('user_address');
            $CI->session->sess_destroy();
			return true;
		}

		


}	

?>